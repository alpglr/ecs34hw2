# Ecs34-hw1

online resources used: 
https://en.wikipedia.org/wiki/Levenshtein_distance
https://www.geeksforgeeks.org/edit-distance-dp-5/
https://www.w3schools.com/python/ref_string_expandtabs.asp
https://www.youtube.com/watch?v=sCXB3IcuENk
